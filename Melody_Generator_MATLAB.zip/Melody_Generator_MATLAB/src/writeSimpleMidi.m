function writeSimpleMidi(filename,pitches,secondsPerNote,velocity)
%WRITESIMPLEMIDI Write a simple monophonic melody as a Standard MIDI File.
if nargin<3, secondsPerNote=0.3; end
if nargin<4, velocity=95; end
pitches = round(pitches(:)');
pitches = min(127,max(0,pitches));
ticksPerQuarter = 480;
tempoMicroseconds = 500000; % 120 BPM
ticksPerNote = max(1,round(secondsPerNote*960)); % 960 ticks/sec at 120 BPM
track = uint8([]);
% Set tempo meta event.
track = [track uint8([0 255 81 3 7 161 32])];
for k=1:numel(pitches)
    track=[track vlq(0) uint8([144 pitches(k) velocity])]; %#ok<AGROW>
    track=[track vlq(ticksPerNote) uint8([128 pitches(k) 0])]; %#ok<AGROW>
end
track=[track uint8([0 255 47 0])];
header=[uint8('MThd') be32(6) be16(0) be16(1) be16(ticksPerQuarter)];
chunk=[uint8('MTrk') be32(numel(track)) track];
fid=fopen(filename,'wb');
if fid<0, error('Cannot create MIDI output file.'); end
fwrite(fid,[header chunk],'uint8'); fclose(fid);
end
function b=be16(x), b=uint8([bitshift(x,-8) bitand(x,255)]); end
function b=be32(x), b=uint8([bitshift(x,-24) bitand(bitshift(x,-16),255) bitand(bitshift(x,-8),255) bitand(x,255)]); end
function b=vlq(x)
x=uint32(x); b=uint8(bitand(x,127)); x=bitshift(x,-7);
while x>0, b=[uint8(bitor(b,128)) uint8(bitand(x,127))]; x=bitshift(x,-7); end
b=fliplr(b);
end
