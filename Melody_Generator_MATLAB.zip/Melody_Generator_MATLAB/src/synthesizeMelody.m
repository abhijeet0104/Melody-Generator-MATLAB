function synthesizeMelody(filename,pitches,secondsPerNote,fs)
%SYNTHESIZEMELODY Synthesize a simple plucked-tone melody to WAV.
if nargin<3, secondsPerNote=0.3; end
if nargin<4, fs=11025; end
pitches=round(pitches(:)');
noteSamples=max(1,round(secondsPerNote*fs));
audio=zeros(1,numel(pitches)*noteSamples);
for k=1:numel(pitches)
    f=440*2.^((pitches(k)-69)/12);
    t=(0:noteSamples-1)/fs;
    env=min(1,t/0.015).*exp(-3*t/secondsPerNote);
    tone=sin(2*pi*f*t)+0.25*sin(4*pi*f*t)+0.1*sin(6*pi*f*t);
    idx=(k-1)*noteSamples+(1:noteSamples);
    audio(idx)=0.22*env.*tone;
end
audio=audio/(max(abs(audio))+eps)*0.95;
audiowrite(filename,audio(:),fs);
end
