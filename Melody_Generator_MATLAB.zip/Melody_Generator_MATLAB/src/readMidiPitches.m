function pitches = readMidiPitches(filename)
%READMIDIPITCHES Minimal Standard MIDI File parser for note-on events.
% Extracts monophonic pitch sequence ordered by event time.
fid = fopen(filename,'rb','ieee-be');
if fid < 0, error('Cannot open MIDI file.'); end
cleanup = onCleanup(@() fclose(fid));
bytes = fread(fid,inf,'*uint8')';
if numel(bytes) < 14 || ~isequal(char(bytes(1:4)),'MThd')
    error('Not a valid Standard MIDI File.');
end
headerLen = readU32(bytes,5);
nTracks = readU16(bytes,11);
pos = 9 + headerLen;
events = [];
for tr = 1:nTracks
    if pos+7 > numel(bytes), break; end
    if ~isequal(char(bytes(pos:pos+3)),'MTrk'), error('Invalid MIDI track chunk.'); end
    len = readU32(bytes,pos+4);
    track = bytes(pos+8:min(pos+7+len,numel(bytes)));
    [ticks, pitchesTrack] = parseTrack(track);
    if ~isempty(ticks)
        events = [events; [ticks(:),pitchesTrack(:)]]; %#ok<AGROW>
    end
    pos = pos + 8 + len;
end
if isempty(events), pitches = []; return; end
events = sortrows(events,1);
pitches = events(:,2)';
end
function [ticks,pitches] = parseTrack(b)
ticks=[]; pitches=[]; i=1; absTick=0; running=0;
while i<=numel(b)
    [delta,i] = readVar(b,i); absTick=absTick+delta;
    if i>numel(b), break; end
    status=b(i);
    if status<128
        if running==0, break; end
        status=running;
    else
        i=i+1;
        if status<240, running=status; end
    end
    if status==255
        if i>numel(b), break; end
        type=b(i); i=i+1;
        [n,i]=readVar(b,i); i=i+n;
        if type==47, break; end
    elseif status==240 || status==247
        [n,i]=readVar(b,i); i=i+n;
    else
        hi=bitand(status,240);
        if hi==192 || hi==208, ndata=1; else, ndata=2; end
        if i+ndata-1>numel(b), break; end
        d1=b(i); if ndata==2, d2=b(i+1); else, d2=0; end
        i=i+ndata;
        if hi==144 && d2>0
            ticks(end+1,1)=absTick; pitches(end+1,1)=double(d1); %#ok<AGROW>
        end
    end
end
end
function [v,i]=readVar(b,i)
v=0;
while i<=numel(b)
    c=double(b(i)); i=i+1;
    v=bitshift(v,7)+bitand(c,127);
    if bitand(c,128)==0, break; end
end
end
function x=readU16(b,p), x=double(b(p))*256+double(b(p+1)); end
function x=readU32(b,p), x=double(b(p))*16777216+double(b(p+1))*65536+double(b(p+2))*256+double(b(p+3)); end
