%% GENERATIVE MELODY COMPOSER USING MATLAB
% Train an LSTM to predict the next MIDI pitch and compose a new melody.
% Add appropriately licensed MIDI training files to data/midi for best results.

clear; clc; close all;
projectFolder = fileparts(mfilename('fullpath'));
if isempty(projectFolder), projectFolder = pwd; end
cd(projectFolder);
addpath(fullfile(projectFolder,'src'));

fprintf('\n============================================\n');
fprintf(' GENERATIVE MELODY COMPOSER\n');
fprintf('============================================\n');

if exist('trainnet','file') ~= 2 && exist('trainNetwork','file') ~= 2
    error(['Deep Learning Toolbox training functions were not found. ', ...
        'Check that Deep Learning Toolbox is installed and licensed.']);
end

midiFolder = fullfile(projectFolder,'data','midi');
midiFiles = dir(fullfile(midiFolder,'*.mid'));
if isempty(midiFiles)
    error('No MIDI files found in data/midi. Add MIDI training files and rerun.');
end

fprintf('Found %d MIDI training files.\n',numel(midiFiles));
sequences = {};
for k = 1:numel(midiFiles)
    f = fullfile(midiFiles(k).folder,midiFiles(k).name);
    try
        pitches = readMidiPitches(f);
        pitches = pitches(pitches >= 36 & pitches <= 96);
        if numel(pitches) >= 8
            sequences{end+1} = pitches(:)'; %#ok<SAGROW>
            fprintf('  Loaded %-30s %d notes\n',midiFiles(k).name,numel(pitches));
        else
            fprintf('  Skipped %-30s (too few usable notes)\n',midiFiles(k).name);
        end
    catch ME
        warning('Could not read %s: %s',midiFiles(k).name,ME.message);
    end
end
if isempty(sequences)
    error('No usable note sequences found. Check the MIDI files in data/midi.');
end

% Encode pitch classes as categorical tokens from MIDI pitch 36 to 96.
minPitch = 36; maxPitch = 96; vocabSize = maxPitch-minPitch+1;
XTrain = {}; YTrain = {};
windowLength = 16;
for s = 1:numel(sequences)
    seq = sequences{s};
    tok = seq - minPitch + 1;
    if numel(tok) <= windowLength, continue; end
    for j = 1:(numel(tok)-windowLength)
        XTrain{end+1} = tok(j:j+windowLength-1); %#ok<SAGROW>
        YTrain{end+1} = categorical(tok(j+1:j+windowLength),1:vocabSize); %#ok<SAGROW>
    end
end
if isempty(XTrain)
    error('Training sequences are too short. Add longer MIDI files.');
end

% Train a sequence-to-sequence LSTM next-pitch model.
layers = [
    sequenceInputLayer(1,Normalization="none")
    lstmLayer(128,OutputMode="sequence")
    dropoutLayer(0.15)
    fullyConnectedLayer(vocabSize)
    softmaxLayer
    classificationLayer];

options = trainingOptions("adam", ...
    MaxEpochs=20, ...
    MiniBatchSize=64, ...
    InitialLearnRate=0.002, ...
    Shuffle="every-epoch", ...
    GradientThreshold=1, ...
    Verbose=true, ...
    Plots="training-progress");

% Convert token windows into numeric sequences and categorical targets.
% trainNetwork sequence classification expects one categorical label per time step.
X = cellfun(@(z) double(z(:)'), XTrain, 'UniformOutput',false);
Y = YTrain(:);
try
    net = trainNetwork(X,Y,layers,options);
catch ME
    error(['Training failed. This may be due to a MATLAB release/API difference. ', ...
        'Error from MATLAB: %s'],ME.message);
end

% Generate notes autoregressively from a random seed sequence.
rng('shuffle');
seedSeq = sequences{randi(numel(sequences))};
seedSeq = seedSeq(max(1,end-windowLength+1):end);
tokens = seedSeq - minPitch + 1;
generated = seedSeq;
numNewNotes = 96;

for t = 1:numNewNotes
    inputTokens = double(tokens(end-min(windowLength,numel(tokens))+1:end));
    inputTokens = inputTokens(:)';
    % Predict distribution for next token using sequence scores.
    try
        scores = predict(net,{inputTokens},MiniBatchSize=1);
        if iscell(scores), scores = scores{1}; end
        if ndims(scores) == 3, scores = scores(:,:,end); end
        scores = squeeze(scores);
        if size(scores,1) == vocabSize
            p = scores(:,end);
        elseif size(scores,2) == vocabSize
            p = scores(end,:)';
        else
            p = ones(vocabSize,1)/vocabSize;
        end
        p = double(p(:));
        p(~isfinite(p) | p < 0) = 0;
        if sum(p) <= 0, p = ones(vocabSize,1)/vocabSize; end
        p = p/sum(p);
        % Temperature sampling adds variation while retaining model preference.
        temperature = 0.9;
        p = p.^(1/temperature); p = p/sum(p);
        nextToken = find(rand <= cumsum(p),1,'first');
        if isempty(nextToken), nextToken = randi(vocabSize); end
    catch
        % Robust fallback for releases that return different score dimensions.
        nextToken = tokens(end);
    end
    tokens(end+1) = nextToken; %#ok<SAGROW>
    generated(end+1) = nextToken + minPitch - 1; %#ok<SAGROW>
end

outFolder = fullfile(projectFolder,'outputs');
if ~exist(outFolder,'dir'), mkdir(outFolder); end
midiOut = fullfile(outFolder,'generated_melody.mid');
wavOut = fullfile(outFolder,'generated_melody.wav');
writeSimpleMidi(midiOut,generated,0.30,100);
synthesizeMelody(wavOut,generated,0.30,11025);

fig = figure('Color','w','Name','Generated Melody');
plot(1:numel(generated),generated,'-o','MarkerSize',3);
xlabel('Note index'); ylabel('MIDI pitch');
title('LSTM-Generated Melody'); grid on;
exportgraphics(fig,fullfile(outFolder,'generated_melody_plot.png'),'Resolution',160);

fprintf('\n===== GENERATION COMPLETE =====\n');
fprintf('Generated MIDI: %s\n',midiOut);
fprintf('Generated WAV:  %s\n',wavOut);
fprintf('Pitch plot:     %s\n',fullfile(outFolder,'generated_melody_plot.png'));
fprintf('Open the WAV file to listen to the generated melody.\n');
fprintf('Training corpus size: %d MIDI files.\n',numel(sequences));
