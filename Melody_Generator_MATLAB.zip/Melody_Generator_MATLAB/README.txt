GENERATIVE MELODY COMPOSER USING MATLAB
=======================================

Main file: run_melody_generator.m
MATLAB target: R2024b or newer recommended
Toolboxes: Deep Learning Toolbox; Audio Toolbox recommended

WHAT THIS PROJECT DOES
1. Reads MIDI files from data/midi.
2. Extracts melody pitches from MIDI note-on/note-off events using a small MIDI parser.
3. Trains an LSTM next-note model with Deep Learning Toolbox.
4. Generates a new sequence of notes.
5. Writes outputs/generated_melody.mid and outputs/generated_melody.wav.
6. Plots training loss and the generated pitch sequence.

IMPORTANT DATASET NOTE
The included MIDI files are small synthetic starter examples created for testing the pipeline.
They are NOT a downloaded public-domain classical dataset and are not sufficient for a strong music-generation model.
For a real submission, add a collection of appropriately licensed MIDI files (for example, a classical piano MIDI corpus) to data/midi, then run the project again. Do not redistribute copyrighted MIDI files without permission.

HOW TO RUN
1. Extract the ZIP.
2. Open MATLAB.
3. Set Current Folder to this project folder.
4. Open run_melody_generator.m.
5. Click Run.

The script checks for Deep Learning Toolbox functions and gives a clear error if required functions are unavailable.
It uses a custom Standard MIDI File parser/writer so no third-party MIDI package is required.
Audio is also synthesized to WAV for reliable playback. Audio Toolbox is detected and reported, but WAV playback is used as a portable fallback.

PROJECT STRUCTURE
run_melody_generator.m      Main entry point
src/readMidiPitches.m       Read note pitches from Standard MIDI Files
src/writeSimpleMidi.m       Write generated monophonic MIDI
src/synthesizeMelody.m      Synthesize WAV audio from generated notes
data/midi/                  Training MIDI files
outputs/                    Generated MIDI, WAV, plots

LIMITATIONS
- The parser extracts note pitches and approximates each MIDI file as a monophonic sequence.
- Note duration, velocity, harmony, and multiple simultaneous instruments are not modelled.
- The included starter MIDI examples are for pipeline testing only.
- A trained model's quality depends strongly on the size, quality, and style consistency of the training corpus.
